"""
Ex. Geophysical structure → MODFLOW → hydrological response
===========================================================

Run a small MODFLOW 6 comparison using the topography and interpreted regolith /
fractured-bedrock depths from Hang Chen's Geophysics_informed_models repository.
The bundled data are 13 KB and require no runtime data download. This example
compares uniform layer thicknesses with spatially varying interpreted interfaces.
Hydraulic properties and forcing are illustrative, not the paper's calibration.
It does not perform seismic inversion or infer conductivity from velocity.

Install ``flopy``, ``numpy``, ``matplotlib`` and PyHydroGeophysX, then run::

    python examples/Ex_MODFLOW_geophysics_feedback.py --download-mf6

Or pass ``--mf6 /path/to/mf6``. ``--write-only`` prepares both input decks without
a solver. Each default run creates a new folder under examples/results. No
ParFlow, GPU, pyGIMLi or GIS installation is needed.

Source: https://github.com/geohang/Geophysics_informed_models
Revision: a23fff3c00c0033f479064cf3651e23b1d5bea07 (Apache-2.0).
The original S4 notebook constructs top - regolith_depth and top - fractured_depth
interfaces at 5 m spacing. Its integrated UZF/SFR/MVR catchment model is replaced
here with prescribed recharge, drains and a fixed-head outlet for a short test.
See data/modflow_informed/provenance.json for exact source files and hashes.
"""
from pathlib import Path
import argparse
import json
import re
import shutil
import tempfile

import numpy as np

from PyHydroGeophysX.model_input import write_modflow6_inputs


def load_structure():
    """Condition the original interfaces explicitly; keep inactive cells finite."""
    with np.load(Path(__file__).parent / 'data/modflow_informed/structure.npz') as data:
        top = data['top'].copy()
        active = data['active'].astype(bool)
        reg = data['regolith_depth'].copy()
        fractured = data['fractured_depth'].copy()
    if not all(np.isfinite(a[active]).all() for a in (top, reg, fractured)):
        raise ValueError('Active source cells must have finite structure data.')
    # Same thin-layer conditioning as S4; no inferred conductivity conversion.
    reg = np.where(active, np.where(reg <= .1, .15, reg), 1.)
    fractured = np.where(active, np.where(fractured <= reg+.1, reg+.15, fractured), 10.)
    top[~active] = np.mean(top[active])
    # Same base in both cases so only internal layer geometry changes.
    base = top - np.maximum(fractured+30., np.mean(fractured[active])+1.)
    informed = np.stack([top-reg, top-fractured, base])
    baseline = np.stack([top-np.mean(reg[active]), top-np.mean(fractured[active]), base])
    return top, active, baseline, informed


def build_baseline(workspace, executable):
    import flopy
    top, active, baseline, informed = load_structure()
    sim = flopy.mf6.MFSimulation(sim_name='structure_demo', sim_ws=str(workspace), exe_name=executable)
    flopy.mf6.ModflowTdis(sim, time_units='DAYS', nper=3,
                         perioddata=[(10.,10,1.)]*3)
    flopy.mf6.ModflowIms(sim, complexity='MODERATE', linear_acceleration='BICGSTAB',
                        outer_dvclose=1e-7, inner_dvclose=1e-8, rcloserecord=1e-6)
    model = flopy.mf6.ModflowGwf(sim, modelname='catchment', save_flows=True)
    shape = baseline.shape
    flopy.mf6.ModflowGwfdis(model, length_units='METERS', nlay=3,
        nrow=shape[1], ncol=shape[2], delr=5., delc=5., top=top,
        botm=baseline, idomain=np.broadcast_to(active,shape).astype(int))
    flopy.mf6.ModflowGwfnpf(model, icelltype=0, k=[1.,.1,.001], k33=[.1,.01,.0001], save_flows=True)
    flopy.mf6.ModflowGwfic(model, strt=np.broadcast_to(top+.1,shape))
    # Confined storage is intentional: this small linear comparison does not model UZF.
    flopy.mf6.ModflowGwfsto(model, iconvert=0, ss=1e-4, sy=.1, transient={0:True})
    row, col = np.unravel_index(np.argmin(np.where(active,top,np.inf)),top.shape)
    flopy.mf6.ModflowGwfchd(model, stress_period_data=[((0,int(row),int(col)),float(top[row,col]))], save_flows=True)
    drains = [((0,int(r),int(c)),float(top[r,c]),1.) for r,c in np.argwhere(active)
              if (r,c)!=(row,col)]
    flopy.mf6.ModflowGwfdrn(model, stress_period_data=drains, save_flows=True)
    flopy.mf6.ModflowGwfrcha(model, recharge={i:np.where(active,rate,0.)
                           for i,rate in enumerate([.001,.003,.001])}, save_flows=True)
    flopy.mf6.ModflowGwfoc(model, head_filerecord='catchment.hds', budget_filerecord='catchment.cbc',
        saverecord=[('HEAD','ALL'),('BUDGET','ALL')], printrecord=[('BUDGET','ALL')])
    sim.write_simulation(silent=True)
    return sim, active, informed


def run_case(folder, executable, active):
    import flopy
    sim = flopy.mf6.MFSimulation.load(sim_ws=str(folder),exe_name=executable,verbosity_level=0)
    ok, report = sim.run_simulation(silent=True,report=True)
    (folder/'solver.log').write_text('\n'.join(report),encoding='utf-8')
    if not ok:
        raise RuntimeError(f'MODFLOW failed; inspect {folder / "solver.log"}')
    model = sim.get_model()
    heads = model.output.head().get_data()
    if not np.isfinite(heads[:,active]).all() or np.any(np.abs(heads[:,active])>1e20):
        raise RuntimeError('Invalid active-cell heads.')
    listing = (folder/'catchment.lst').read_text(errors='replace')
    discrepancy = [abs(float(x)) for x in re.findall(r'PERCENT DISCREPANCY\s*=\s*([-+\d.Ee]+)',listing)]
    if not discrepancy or max(discrepancy) > .1:
        raise RuntimeError('Missing or excessive water-budget discrepancy.')
    budget = model.output.budget()
    times = budget.get_times()
    discharge = [-float(budget.get_data(text='DRN',totim=t)[0]['q'].sum()) for t in times]
    return heads, np.asarray(times), np.asarray(discharge), max(discrepancy)


def run_example(output, *, mf6=None, download=False, write_only=False):
    output = Path(output).resolve()
    output.mkdir(parents=True,exist_ok=False)
    executable = str(Path(mf6).resolve()) if mf6 else shutil.which('mf6')
    if not write_only and executable is None and download:
        from flopy.utils import get_modflow
        binary = output/'bin'
        binary.mkdir()
        get_modflow(str(binary),subset='mf6',quiet=True)
        executable = str(next(binary.glob('mf6*')))
    if not write_only and executable is None:
        raise FileNotFoundError('Supply --mf6 or use --download-mf6; --write-only needs no executable.')
    sim, active, informed = build_baseline(output/'baseline',executable or 'mf6')
    write_modflow6_inputs(sim,output/'informed',{'bottom_elevation':informed})
    if write_only:
        return {'output':str(output),'status':'inputs_written_not_run'}
    base_head, times, base_q, base_error = run_case(output/'baseline',executable,active)
    informed_head, informed_times, informed_q, informed_error = run_case(output/'informed',executable,active)
    np.testing.assert_array_equal(times,informed_times)
    summary = {'status':'both_simulations_completed', 'output':str(output),
        'active_cells':int(active.sum()*3),'steps':len(times),
        'max_head_change_m':float(np.max(np.abs(informed_head[:,active]-base_head[:,active]))),
        'max_budget_discrepancy_percent':max(base_error,informed_error),
        'interpretation':'Sensitivity to interpreted structure, not evidence of improved prediction.'}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez_compressed(output/'comparison.npz',baseline_head=base_head,informed_head=informed_head,
                        time_days=times,baseline_drain_m3_day=base_q,informed_drain_m3_day=informed_q,active=active)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1,3,figsize=(13,4),layout='constrained')
    top, _, _, _ = load_structure()
    artist = axes[0].imshow(np.where(active,top-informed[1],np.nan),cmap='viridis')
    axes[0].set_title('Interpreted fractured-zone depth')
    fig.colorbar(artist,ax=axes[0],label='m below ground')
    difference = np.where(active,informed_head[0]-base_head[0],np.nan)
    limit = max(float(np.nanmax(np.abs(difference))),1e-12)
    artist = axes[1].imshow(difference,cmap='coolwarm',vmin=-limit,vmax=limit)
    axes[1].set_title('Final head: informed − baseline')
    fig.colorbar(artist,ax=axes[1],label='m')
    for ax in axes[:2]:
        ax.set(xlabel='Column (5 m cells)',ylabel='Row (5 m cells)')
    axes[2].plot(times,base_q,label='Uniform thickness')
    axes[2].plot(times,informed_q,label='Geophysical structure')
    axes[2].set(xlabel='Time (days)',ylabel='Drain discharge (m³/day)',title='Hydrological response')
    axes[2].legend()
    fig.savefig(output/'comparison.png',dpi=150)
    plt.close(fig)
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mf6',help='Path to MODFLOW 6 executable')
    parser.add_argument('--download-mf6',action='store_true',help='Download official executable using FloPy')
    parser.add_argument('--write-only',action='store_true')
    parser.add_argument('--output',type=Path,help='New output directory; existing paths are refused')
    args = parser.parse_args()
    if args.output is None:
        root = Path(__file__).parent/'results'
        root.mkdir(exist_ok=True)
        # Reserve a unique parent; run_example creates the model directory below it.
        args.output = Path(tempfile.mkdtemp(prefix='modflow-feedback-',dir=root))/'run'
    print(json.dumps(run_example(args.output,mf6=args.mf6,download=args.download_mf6,
                                 write_only=args.write_only),indent=2))
